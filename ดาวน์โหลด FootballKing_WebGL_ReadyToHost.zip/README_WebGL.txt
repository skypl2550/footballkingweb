Football King - WebGL 3D Version (Mock Demo)

⚠️ โปรเจกต์นี้เป็นตัวอย่างโครงสร้าง WebGL พร้อม index.html สำหรับอัปโหลดขึ้น GitHub Pages

ไฟล์จริงต้องใช้ Unity สร้าง Build จากโค้ด 3D ซึ่งต้องดำเนินการภายนอกระบบนี้

การใช้งาน:
1. แตกไฟล์
2. เปิด index.html
3. หากคุณนำไปอัปโหลดที่ GitHub Pages จะสามารถรันได้ทันที

ต้องการให้เราสร้าง Unity WebGL จริง? ติดต่อเพื่อรับไฟล์ Build จาก Unity Engine

